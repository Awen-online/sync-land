<?php
// This file was auto-generated from sdk-root/src/data/endpoints_prefix_history.json
return [ 'prefix-groups' => [ 'api.ecr' => [ 'ecr', ], 'api.elastic-inference' => [ 'elastic-inference', ], 'api.sagemaker' => [ 'sagemaker', ], 'ecr' => [ 'api.ecr', ], 'elastic-inference' => [ 'api.elastic-inference', ], 'sagemaker' => [ 'api.sagemaker', ], ],];
