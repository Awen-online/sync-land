<?php
// This file was auto-generated from sdk-root/src/data/dlm/2018-01-12/paginators-1.json
return [ 'pagination' => [],];
